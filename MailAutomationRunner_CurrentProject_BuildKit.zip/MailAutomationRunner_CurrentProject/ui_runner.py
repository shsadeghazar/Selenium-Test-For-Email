import html
import importlib
from contextlib import redirect_stderr, redirect_stdout
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, messagebox
import zipfile

import jdatetime
# Explicit imports are required for native/frozen builds because Selenium loads
# these modules lazily at runtime.
from selenium.webdriver.chrome.webdriver import WebDriver as _BundledChromeWebDriver
from selenium.webdriver.chrome.service import Service as _BundledChromeService
from selenium.webdriver.remote.webdriver import WebDriver as _RemoteWebDriver

APP_NAME = "MailAutomationRunner"
_BROWSER_PATCHED = False
TEST_SCRIPTS = {
    "لاگین و ذخیره سشن": "login_and_save",
    "ارسال ایمیل ساده": "test_send_email",
    "ارسال ایمیل با پیوست": "test_send_with_attachment",
    "ارسال ایمیل با پیوست و امضا": "test_send_mail_with_signature",
    "ذخیره پیش‌نویس همراه با پیوست": "test_save_draft_with_attachment",
    "ارسال پیش‌نویس ذخیره‌شده": "test_send_saved_draft",
    "ریپلای ساده به اولین ایمیل": "test_reply_email",
    "ریپلای پیشرفته (با پیوست و CC/BCC)": "test_reply_with_attachment",
    "ریپلای پیشرفته با امضا": "test_reply_with_signature",
    "ساخت پوشه و پوشه تکراری": "test_create_folder",
    "تغییر وضعیت خوانده شده/نخوانده": "test_mark_read_unread",
    "انتقال به هرزنامه": "test_move_to_spam",
    "خارج کردن از هرزنامه": "test_remove_from_spam",
    "ریپلای پیشرفته از صندوق ارسال": "test_reply_with_attachment_from_sent",
    "تغییر وضعیت خوانده شده/نخوانده در صندوق ارسال": "test_mark_read_unread_sent",
    "انتشار برچسب روی صندوق‌های مختلف": "test_tag_propagation",
    "تست انتقال پوشه": "test_folder_and_move",
    " تست خوانده شده خوانده نشده در صندوق ارسال": "test_mark_read_unread_sent",
}


def app_data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    path = Path(base) / APP_NAME if base else Path.home() / f".{APP_NAME}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def install_bundled_browser():
    """Make Selenium use the Chrome and driver shipped in the one-file build."""
    global _BROWSER_PATCHED
    if _BROWSER_PATCHED:
        return

    from selenium import webdriver
    bundle = Path(__file__).resolve().parent
    archive = bundle / "bundled_browser.zip"
    browser_dir = app_data_dir() / "browser"
    chrome = browser_dir / "chrome.exe"
    driver = browser_dir / "chromedriver.exe"

    if not chrome.exists() or not driver.exists():
        if not archive.exists():
            raise FileNotFoundError(f"آرشیو مرورگر داخل EXE پیدا نشد: {archive}")
        if browser_dir.exists():
            shutil.rmtree(browser_dir)
        browser_dir.mkdir(parents=True)
        print("[ℹ️] اولین اجرا: در حال استخراج مرورگر داخلی...", flush=True)
        with zipfile.ZipFile(archive, "r") as browser_zip:
            browser_zip.extractall(browser_dir)

    if not chrome.exists() or not driver.exists():
        raise FileNotFoundError(
            f"استخراج مرورگر ناقص بود؛ Chrome={chrome.exists()} Driver={driver.exists()} Path={browser_dir}"
        )

    original = webdriver.Chrome

    def bundled_chrome(*args, **kwargs):
        print(f"[ℹ️] راه‌اندازی Chrome داخلی از: {chrome}", flush=True)
        options = kwargs.get("options")
        if options is None:
            options = webdriver.ChromeOptions()
            kwargs["options"] = options
        options.binary_location = str(chrome)
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        kwargs.setdefault("service", _BundledChromeService(str(driver)))
        return original(*args, **kwargs)

    webdriver.Chrome = bundled_chrome
    _BROWSER_PATCHED = True


def run_test_child(module_name):
    os.chdir(app_data_dir())
    install_bundled_browser()
    module = importlib.import_module(f"mail_tests.{module_name}")
    module.run()


def run_self_test():
    """Validate the actual frozen EXE, embedded modules, driver, and Chrome."""
    log_path = app_data_dir() / "self-test.log"
    with log_path.open("w", encoding="utf-8") as log:
        with redirect_stdout(log), redirect_stderr(log):
            try:
                print("[SELF-TEST] Importing compiled scenario modules...", flush=True)
                for module_name in dict.fromkeys(TEST_SCRIPTS.values()):
                    importlib.import_module(f"mail_tests.{module_name}")
                print("[SELF-TEST] All scenario modules imported.", flush=True)

                install_bundled_browser()
                from selenium import webdriver

                options = webdriver.ChromeOptions()
                options.add_argument("--headless=new")
                options.add_argument("--disable-gpu")
                options.add_argument("--window-size=800,600")
                browser = webdriver.Chrome(options=options)
                try:
                    browser.set_page_load_timeout(20)
                    browser.get("data:text/html,<title>MailRunnerSmokeOK</title><h1>OK</h1>")
                    if browser.title != "MailRunnerSmokeOK":
                        raise RuntimeError(f"Unexpected browser title: {browser.title!r}")
                finally:
                    browser.quit()

                print("[SELF-TEST] PASS: compiled EXE and bundled Chrome are operational.", flush=True)
                return 0
            except BaseException:
                print("[SELF-TEST] FAIL", flush=True)
                traceback.print_exc(file=log)
                return 1


if len(sys.argv) == 2 and sys.argv[1] == "--self-test":
    raise SystemExit(run_self_test())


if len(sys.argv) == 3 and sys.argv[1] == "--run-test":
    try:
        run_test_child(sys.argv[2])
    except BaseException as exc:
        print(f"❌ اجرای سناریو ناموفق بود: {exc}", flush=True)
        raise
    raise SystemExit(0)


DATA_DIR = app_data_dir()
LOG_DIR = DATA_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
os.chdir(DATA_DIR)

root = tk.Tk()
root.title("Mail Automation Runner")
root.geometry("720x900")
root.configure(padx=18, pady=12)

style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", font=("Tahoma", 9, "bold"), padding=5)
style.configure("TLabelframe.Label", font=("Tahoma", 10, "bold"))

inputs = ttk.LabelFrame(root, text=" تنظیمات سامانه ", padding=12)
inputs.pack(fill="x", pady=6)


def add_entry(row, label, default="", secret=False):
    ttk.Label(inputs, text=label, font=("Tahoma", 9)).grid(row=row, column=0, sticky="w", pady=4)
    entry = ttk.Entry(inputs, width=58, show="*" if secret else "")
    entry.grid(row=row, column=1, padx=8, pady=4)
    entry.insert(0, default)
    return entry


url_entry = add_entry(0, "لینک سامانه:", "https://mail.chbeta.ir/nui/")
user_entry = add_entry(1, "نام کاربری:")
pass_entry = add_entry(2, "رمز عبور:", secret=True)
email_entry = add_entry(3, "گیرنده (با کاما جدا شود):")
cc_entry = add_entry(4, "CC (اختیاری):")
bcc_entry = add_entry(5, "BCC (اختیاری):")

date_frame = ttk.Frame(inputs)
date_frame.grid(row=6, column=1, sticky="w", padx=8, pady=4)
ttk.Label(inputs, text="تاریخ اجرا (شمسی):").grid(row=6, column=0, sticky="w")
now = jdatetime.datetime.now()
year_var = tk.StringVar(value=str(now.year))
month_var = tk.StringVar(value=f"{now.month:02d}")
day_var = tk.StringVar(value=f"{now.day:02d}")
for var, values, width in (
    (year_var, [str(i) for i in range(1402, 1416)], 6),
    (month_var, [f"{i:02d}" for i in range(1, 13)], 4),
    (day_var, [f"{i:02d}" for i in range(1, 32)], 4),
):
    ttk.Combobox(date_frame, textvariable=var, values=values, width=width, state="readonly").pack(side="left", padx=2)

tests_frame = ttk.LabelFrame(root, text=" سناریوها ", padding=8)
tests_frame.pack(fill="both", expand=True, pady=6)
canvas = tk.Canvas(tests_frame, highlightthickness=0)
scroll = ttk.Scrollbar(tests_frame, orient="vertical", command=canvas.yview)
rows = ttk.Frame(canvas)
rows.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
rows_window = canvas.create_window((0, 0), window=rows, anchor="nw")
canvas.configure(yscrollcommand=scroll.set)
canvas.pack(side="left", fill="both", expand=True)
scroll.pack(side="right", fill="y")


def resize_scenario_rows(event):
    canvas.itemconfigure(rows_window, width=event.width)


def scroll_scenarios(event):
    bounds = canvas.bbox("all")
    if not bounds or bounds[3] <= canvas.winfo_height():
        return "break"
    delta = -1 if event.delta > 0 else 1
    canvas.yview_scroll(delta, "units")
    return "break"


def enable_scenario_wheel(_event):
    canvas.bind_all("<MouseWheel>", scroll_scenarios)


def disable_scenario_wheel(_event):
    canvas.unbind_all("<MouseWheel>")


canvas.bind("<Configure>", resize_scenario_rows)
canvas.bind("<Enter>", enable_scenario_wheel)
canvas.bind("<Leave>", disable_scenario_wheel)

test_vars, status_labels, log_buttons = {}, {}, {}
for i, (name, module) in enumerate(TEST_SCRIPTS.items()):
    var = tk.BooleanVar(value=True)
    test_vars[name] = var
    ttk.Checkbutton(rows, text=name, variable=var, width=35).grid(row=i, column=0, sticky="w", pady=4)
    status = ttk.Label(rows, text="آماده", width=18, foreground="gray")
    status.grid(row=i, column=1, padx=8)
    status_labels[name] = status
    button = ttk.Button(rows, text="مشاهده لاگ", state=tk.DISABLED)
    button.grid(row=i, column=2)
    log_buttons[name] = button

log_text = tk.Text(root, height=12, bg="#1e1e1e", fg="white", font=("Consolas", 10))
for tag, color in (("success", "#00ff00"), ("error", "#ff4444"), ("info", "#34dbeb"), ("normal", "#dddddd")):
    log_text.tag_config(tag, foreground=color)
log_text.pack(fill="both", expand=True, pady=6)


def open_log(path):
    try:
        os.startfile(path)
    except Exception as exc:
        messagebox.showerror("خطا", str(exc))


def save_and_run():
    values = {
        "url": url_entry.get().strip(),
        "username": user_entry.get().strip(),
        "password": pass_entry.get().strip(),
        "target_email": email_entry.get().strip(),
        "cc_email": cc_entry.get().strip(),
        "bcc_email": bcc_entry.get().strip(),
        "run_date": f"{year_var.get()}-{month_var.get()}-{day_var.get()}",
    }
    if not all(values[k] for k in ("url", "username", "password", "target_email")):
        messagebox.showwarning("خطا", "فیلدهای الزامی را کامل کنید.")
        return
    selected = [(n, TEST_SCRIPTS[n]) for n, v in test_vars.items() if v.get()]
    if not selected:
        messagebox.showwarning("خطا", "حداقل یک سناریو را انتخاب کنید.")
        return
    (DATA_DIR / "config.json").write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding="utf-8")
    run_btn.config(state=tk.DISABLED)

    class LiveCapture:
        def __init__(self):
            self.parts = []
            self.success_steps = 0
            self.error_steps = 0

        def write(self, value):
            if not value:
                return 0
            self.parts.append(value)
            for line in value.splitlines():
                if "[✓]" in line or "✅" in line or "[🛡️]" in line:
                    self.success_steps += 1
                elif "[⚠️]" in line or "❌" in line:
                    self.error_steps += 1
            tag = "error" if "❌" in value or "[⚠️]" in value else "success" if "✅" in value or "[✓]" in value else "normal"
            root.after(0, lambda s=value, t=tag: (log_text.insert(tk.END, s, t), log_text.see(tk.END)))
            return len(value)

        def flush(self):
            return None

    def worker():
        stamp = jdatetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        for name, module in selected:
            root.after(0, lambda n=name: status_labels[n].config(text="در حال اجرا…", foreground="blue"))
            path = LOG_DIR / f"{module}_{stamp}.html"
            capture = LiveCapture()
            failed = False
            try:
                with redirect_stdout(capture), redirect_stderr(capture):
                    run_test_child(module)
            except BaseException as exc:
                failed = True
                capture.write(f"\n❌ اجرای سناریو ناموفق بود: {exc}\n")
                capture.write(traceback.format_exc())

            output = "".join(capture.parts)
            body = "".join(f"<div>{html.escape(line)}</div>" for line in output.splitlines())
            path.write_text(f"<html dir='rtl'><meta charset='utf-8'><body style='background:#1e1e1e;color:#eee;font-family:Tahoma'>{body}</body></html>", encoding="utf-8")
            total_steps = capture.success_steps + capture.error_steps
            percentage = (
                int(capture.success_steps * 100 / total_steps)
                if total_steps
                else (0 if failed else 100)
            )
            if percentage == 100 and not failed:
                status_text, status_color = f"✅ موفق ({percentage}٪)", "green"
            elif percentage > 0:
                status_text, status_color = f"⚠️ ناقص ({percentage}٪)", "#d35400"
            else:
                status_text, status_color = f"❌ شکست ({percentage}٪)", "red"
            root.after(0, lambda n=name, p=path, text=status_text, color=status_color: (
                status_labels[n].config(text=text, foreground=color),
                log_buttons[n].config(state=tk.NORMAL, command=lambda: open_log(str(p))),
            ))
        root.after(0, lambda: run_btn.config(state=tk.NORMAL))

    threading.Thread(target=worker, daemon=True).start()


run_btn = ttk.Button(root, text="شروع اجرای تست‌ها", command=save_and_run)
run_btn.pack(fill="x", pady=6)
root.mainloop()
