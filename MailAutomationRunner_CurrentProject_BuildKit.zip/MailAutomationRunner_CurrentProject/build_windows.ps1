$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

py -3.12 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install nuitka selenium jdatetime ordered-set zstandard

$manifest = Invoke-RestMethod "https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json"
$stable = $manifest.channels.Stable
$chromeUrl = ($stable.downloads.chrome | Where-Object platform -eq "win64").url
$driverUrl = ($stable.downloads.chromedriver | Where-Object platform -eq "win64").url

New-Item -ItemType Directory -Force browser-download | Out-Null
Invoke-WebRequest $chromeUrl -OutFile browser-download\chrome.zip
Invoke-WebRequest $driverUrl -OutFile browser-download\driver.zip
Expand-Archive browser-download\chrome.zip browser-download\chrome -Force
Expand-Archive browser-download\driver.zip browser-download\driver -Force

if (Test-Path browser) {
    Remove-Item browser -Recurse -Force
}
New-Item -ItemType Directory browser | Out-Null
Copy-Item browser-download\chrome\chrome-win64\* browser -Recurse -Force
Copy-Item browser-download\driver\chromedriver-win64\chromedriver.exe browser\chromedriver.exe -Force
Compress-Archive `
  -Path browser\* `
  -DestinationPath bundled_browser.zip `
  -CompressionLevel Optimal `
  -Force

& .\.venv\Scripts\python.exe -m nuitka `
  --onefile `
  --enable-plugin=tk-inter `
  --windows-console-mode=hide `
  --include-package=mail_tests `
  --include-package=selenium `
  --include-package=urllib3 `
  --include-package=websocket `
  --include-module=session_url `
  --include-module=selenium.webdriver.chrome.webdriver `
  --include-module=selenium.webdriver.remote.webdriver `
  --include-data-files=bundled_browser.zip=bundled_browser.zip `
  --output-filename=MailAutomationRunner.exe `
  --output-dir=dist `
  ui_runner.py

if (!(Test-Path dist\MailAutomationRunner.exe)) {
    throw "Build failed: EXE was not created."
}

$selfTestLog = Join-Path $env:LOCALAPPDATA "MailAutomationRunner\self-test.log"
$selfTestBrowser = Join-Path $env:LOCALAPPDATA "MailAutomationRunner\browser"
if (Test-Path $selfTestLog) {
    Remove-Item $selfTestLog -Force
}
if (Test-Path $selfTestBrowser) {
    Remove-Item $selfTestBrowser -Recurse -Force
}
Write-Host "Running mandatory smoke test on the compiled EXE..."
$selfTest = Start-Process `
  -FilePath (Resolve-Path "dist\MailAutomationRunner.exe") `
  -ArgumentList "--self-test" `
  -Wait `
  -PassThru
if (Test-Path $selfTestLog) {
    Get-Content $selfTestLog
}
if ($selfTest.ExitCode -ne 0) {
    throw "Smoke test failed. See: $selfTestLog"
}

Write-Host "Ready: $PSScriptRoot\dist\MailAutomationRunner.exe"
